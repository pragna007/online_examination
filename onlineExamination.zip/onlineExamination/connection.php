<?php 
$url="http://localhost/onlineExamination/";
?>