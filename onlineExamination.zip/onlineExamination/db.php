<?php 
date_default_timezone_set('America/Chicago');
$con = mysqli_connect('localhost','root','','online_examination_new');
if(!$con){
    echo 'Connection Failed';
}

?>